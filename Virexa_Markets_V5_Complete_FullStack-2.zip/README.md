# Virexa Markets V5

Full-stack development foundation for a forex/CFD brokerage platform.

## Included

- Public marketing site
- Client registration/login/logout
- bcrypt password hashing
- Server-side sessions
- Rate-limited authentication endpoints
- Helmet security headers
- Client portal
- KYC status display
- Transaction history
- Security center
- Separate admin authentication
- Server-side role checks
- Admin client directory
- KYC review controls
- Audit log
- Operations status controls
- SQLite database
- Dockerfile
- Basic automated tests

## Run locally

1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Set a strong `SESSION_SECRET`.
4. Change `ADMIN_PASSWORD`.
5. Run `npm install`.
6. Run `npm start`.
7. Open http://localhost:3000

Default development admin:
- Email: admin@virexa.local
- Password: ChangeMe-Admin-123!

Change it before any deployment.

## Important

This is a software development foundation, not a licensed brokerage operation.

Deposits, withdrawals, client-money custody, and live order execution are intentionally disabled. Before enabling those functions, the operator needs the appropriate legal/regulatory structure, required registration/licensing, KYC/AML controls, payment/client-money arrangements, liquidity/execution provider, reconciliations, security review, monitoring, incident response, and tested operational controls.

For Nigeria, review the Securities and Exchange Commission's current online forex/CFD requirements and registration position before offering the service to Nigerian residents.

## Production hardening still required

- PostgreSQL or managed relational database
- Redis/session store
- HTTPS/TLS
- Secure cookies
- MFA for administrators and sensitive actions
- Password reset + verified email
- CSRF protection where applicable
- Strong CSP and security headers
- Secrets manager
- WAF/CDN/rate limiting
- KYC/identity provider
- AML/sanctions/PEP screening
- Payment provider and regulated client-money arrangement
- Trading/execution/LP integration
- Double-entry ledger and reconciliation
- Immutable audit/monitoring pipeline
- Backups and disaster recovery
- Penetration testing and independent security review
- Legal/compliance approval
