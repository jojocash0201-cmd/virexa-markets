const test = require("node:test");
const assert = require("node:assert/strict");

test("Virexa configuration keeps production money movement disabled", () => {
  const productionControls = {
    deposits: false,
    withdrawals: false,
    custody: false,
    liveTrading: false
  };
  assert.equal(productionControls.deposits, false);
  assert.equal(productionControls.withdrawals, false);
  assert.equal(productionControls.custody, false);
  assert.equal(productionControls.liveTrading, false);
});
