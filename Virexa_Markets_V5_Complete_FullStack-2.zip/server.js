const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === "production";

if (isProd && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error("SESSION_SECRET must be set to a strong value (32+ chars) in production.");
}

const db = new Database(path.join(__dirname, "data", "virexa.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'client',
  account_type TEXT NOT NULL DEFAULT 'standard',
  kyc_status TEXT NOT NULL DEFAULT 'pending',
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login_at TEXT
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  amount REAL NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_user_id INTEGER,
  action TEXT NOT NULL,
  target_user_id INTEGER,
  metadata TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const adminEmail = process.env.ADMIN_EMAIL || "admin@virexa.local";
const adminPassword = process.env.ADMIN_PASSWORD || "ChangeMe-Admin-123!";
const existingAdmin = db.prepare("SELECT id FROM users WHERE email = ?").get(adminEmail);

if (!existingAdmin) {
  const hash = bcrypt.hashSync(adminPassword, 12);
  db.prepare(`
    INSERT INTO users (email, password_hash, role, account_type, kyc_status)
    VALUES (?, ?, 'admin', 'internal', 'verified')
  `).run(adminEmail, hash);
}

function audit(actorUserId, action, targetUserId = null, metadata = {}) {
  db.prepare(`
    INSERT INTO audit_logs (actor_user_id, action, target_user_id, metadata)
    VALUES (?, ?, ?, ?)
  `).run(actorUserId || null, action, targetUserId, JSON.stringify(metadata));
}

function publicUser(u) {
  return {
    id: u.id,
    email: u.email,
    role: u.role,
    accountType: u.account_type,
    kycStatus: u.kyc_status,
    status: u.status,
    createdAt: u.created_at,
    lastLoginAt: u.last_login_at
  };
}

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Authentication required" });
  const user = db.prepare("SELECT * FROM users WHERE id = ? AND status = 'active'").get(req.session.userId);
  if (!user) {
    req.session.destroy(() => {});
    return res.status(401).json({ error: "Session invalid" });
  }
  req.user = user;
  next();
}

function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (req.user.role !== "admin") return res.status(403).json({ error: "Admin access required" });
    next();
  });
}

app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(express.json({ limit: "100kb" }));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many authentication attempts. Please try again later." }
});

app.use(session({
  name: "virexa.sid",
  secret: process.env.SESSION_SECRET || "CHANGE_THIS_IN_PRODUCTION",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProd || process.env.COOKIE_SECURE === "true",
    sameSite: "lax",
    maxAge: 30 * 60 * 1000
  }
}));

app.post("/api/register", authLimiter, async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const accountType = ["standard", "pro", "demo"].includes(req.body.accountType) ? req.body.accountType : "standard";

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email." });
  if (password.length < 10) return res.status(400).json({ error: "Password must be at least 10 characters." });

  const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (exists) return res.status(409).json({ error: "An account with that email already exists." });

  const hash = await bcrypt.hash(password, 12);
  const result = db.prepare(`
    INSERT INTO users (email, password_hash, role, account_type, kyc_status)
    VALUES (?, ?, 'client', ?, 'pending')
  `).run(email, hash, accountType);

  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not create session." });
    req.session.userId = result.lastInsertRowid;
    audit(Number(result.lastInsertRowid), "client_registered", Number(result.lastInsertRowid), { accountType });
    res.json({ ok: true });
  });
});

app.post("/api/login", authLimiter, async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

  if (!user || !(await bcrypt.compare(password, user.password_hash)) || user.status !== "active") {
    return res.status(401).json({ error: "Invalid credentials." });
  }

  db.prepare("UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?").run(user.id);

  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start session." });
    req.session.userId = user.id;
    audit(user.id, "login", user.id);
    res.json({ ok: true, user: publicUser({ ...user, last_login_at: new Date().toISOString() }) });
  });
});

app.post("/api/logout", (req, res) => {
  const id = req.session.userId || null;
  if (id) audit(id, "logout", id);
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

app.get("/api/transactions", requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT id, type, amount, currency, status, created_at
    FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT 50
  `).all(req.user.id);
  res.json({ transactions: rows });
});

app.get("/api/admin/stats", requireAdmin, (req, res) => {
  const users = db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'client'").get().c;
  const pendingKyc = db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'client' AND kyc_status = 'pending'").get().c;
  const audit = db.prepare("SELECT COUNT(*) c FROM audit_logs").get().c;
  res.json({ users, pendingKyc, audit, liveTrading: false, payments: false, custody: false });
});

app.get("/api/admin/users", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT id, email, role, account_type, kyc_status, status, created_at, last_login_at
    FROM users ORDER BY id DESC
  `).all();
  res.json({ users: rows });
});

app.patch("/api/admin/users/:id/kyc", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const status = String(req.body.status || "");
  if (!["pending", "verified", "rejected"].includes(status)) {
    return res.status(400).json({ error: "Invalid KYC status." });
  }
  const target = db.prepare("SELECT id, email FROM users WHERE id = ?").get(id);
  if (!target) return res.status(404).json({ error: "User not found." });

  db.prepare("UPDATE users SET kyc_status = ? WHERE id = ?").run(status, id);
  audit(req.user.id, "kyc_status_changed", id, { status });
  res.json({ ok: true });
});

app.get("/api/admin/audit", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT a.id, a.action, a.target_user_id, a.metadata, a.created_at,
           actor.email AS actor_email
    FROM audit_logs a
    LEFT JOIN users actor ON actor.id = a.actor_user_id
    ORDER BY a.id DESC LIMIT 200
  `).all();
  res.json({ logs: rows });
});

app.post("/api/deposit", requireAuth, (req, res) => {
  res.status(403).json({ error: "Deposits are disabled in this development build." });
});

app.post("/api/withdraw", requireAuth, (req, res) => {
  res.status(403).json({ error: "Withdrawals are disabled in this development build." });
});

app.post("/api/orders", requireAuth, (req, res) => {
  res.status(403).json({ error: "Live trading is disabled in this development build." });
});

app.get("/health", (req, res) => res.json({ ok: true, service: "virexa-markets", liveTrading: false }));

app.use(express.static(path.join(__dirname, "public")));

app.listen(PORT, () => {
  console.log(`Virexa Markets running on http://localhost:${PORT}`);
});
